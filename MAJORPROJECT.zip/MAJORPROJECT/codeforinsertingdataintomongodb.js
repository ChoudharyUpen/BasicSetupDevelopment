// This is a code for inserting data into mongodb database

 for (const post of posts) {
        try {
            const newPost = new Post(post);
            await newPost.save();
            console.log(`Post "${post.title}" inserted successfully`);
        } catch (error) {
            console.error(`Error inserting post: ${error.message}`);
        }
    }

    console.log("All posts inserted!");